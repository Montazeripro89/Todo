import Todos from "./components/Todos"

function App() {


  return (
    <>
        <div className="bg-gray-100">
            <Todos />
        </div>
    </>
  )
}

export default App
